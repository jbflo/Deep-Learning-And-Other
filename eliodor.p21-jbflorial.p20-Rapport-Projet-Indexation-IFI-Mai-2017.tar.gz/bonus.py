#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
#title           :HistogrammeQnt.py PLUSIEURS	HISTOGRAMMES	COULEURS	PAR	IMAGE
#description     : histogrammes couleurs quantifiés avec Image / 4
#author          : Florial Jean Baptiste , Eliodor Ednalson Guy Merlin 
#date            : 3/05/2017
#version         :0.1
#usage           :python HistogrammeQnt.py 
#notes           : Nous avons ultile la foction D'open CV 
#python_version  :3.6.0 
#=======================================================================

from matplotlib import pyplot as plt
import numpy as np
import argparse
import cv2

# "Nom de l'image Entrer au clavier")
print ("Entrer le	 nom du fichier image :")
monfichier= input(" >>  ")

#images = image_slicer.slice(monfichier, 4)

#"Valeur pour la reduction de l'histogramme")
print ("Entrer la valeur permettant la reduction de l'Histogramme")
valeur_hist = input(" >>  ")
image = list(cv2.imread(monfichier))
image = image[0:4]
#print(image[0:4])

# grab the image channels, initialize the tuple of colors,
# the figure and the flattened feature vector

#chans = cv2.split(image)
colors = ("b", "g", "r")
plt.figure()
plt.title("histogrammes couleurs quantifiés avec Image / 4")
plt.xlabel("Bins")
plt.ylabel("# of Pixels")
features = []
# loop over the image channels
for img in image:
	# create a histogram for the current channel and
	# concatenate the resulting histograms for each channel
    
	hist = cv2.calcHist([img], [0], None, [int(valeur_hist)], [0, int(valeur_hist)])
	features.extend(hist)

	# plot the histogram
	plt.plot(hist)
	plt.xlim([0, int(valeur_hist)])
	#plt.show() # pour Afficher les 4 Histo 
	
     

	# show the figures 
	

print ("2D histogrammes shape: %s, with %d values" % (
	hist.shape, hist.flatten().shape[0]))

plt.show() # pour Afficher l'Histo Globale 
	
