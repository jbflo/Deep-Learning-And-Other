#
from scipy.spatial import distance as dist
import matplotlib.pyplot as plt
import numpy as np
import argparse
import glob
import cv2


#!/usr/bin/env python
# -*- coding: utf-8 -*-
#title           :projetfinal.py
#description     :This program displays an interactive menu on CLI
#author          : Florial Jean Baptiste , Eliodor Ednalson Guy Merlin 
#date            : 3/05/2017
#version         :0.1
#usage           :python rojetfinal.py
#notes           :Le menu Principale du Projet
#python_version  :3.6.0 
#=======================================================================
 
# Import the modules needed to run the script.
import sys, os
 
# Main definition - constants
menu_actions  = {}  
 
# =======================
#     MENUS FUNCTIONS
# =======================
 
# Main menu
def main_menu():
    os.system('clear')
    
    print ("BIENVENUE AU PROJET, INDEXATION MULTIMODALE DES CONTENUS : PROJET FINAL \n")
    print ("SVP Choisissez un menu pour demarrer: \n")
    print ("1. DESCRIPTION GLOBALE DU CONTENU DES IMAGES")
    print ("2. SYSTEME DE	RECHERCHE D’IMAGES SIMILAIRES")
    print ("3. FONCTION GLOBALE DE	 SIMILARITE ENTRE	 DEUX IMAGES")
    print ("4. CLUSTERING : K-MEANS")
    print ("5. Utilisation de	descripteurs locaux et approche Bag-of-Words")
    print ("6. BONUS")
    print ("\n0. Quitter")
    choice = input(" >>  ")
    exec_menu(choice)
 
    return
 
# Execute menu
def exec_menu(choice):
    os.system('clear')
    ch = choice.lower()
    if ch == '':
        menu_actions['main_menu']()
    else:
        try:
            menu_actions[ch]()
        except KeyError:
            print ("Invalid selection, please try again.\n")
            menu_actions['main_menu']()
    return
 
# Menu 1
def menu1():
    print ("Bienvenue a, DESCRIPTION GLOBALE DU CONTENU DES IMAGES \n")
    print ("SVP Choisissez un menu pour demarrer: \n")
    
    print ("7. Les histogrammes couleurs quantifiés	")
    print ("8. Les moments de	Hu")
    
    print ("11. Back")
    print ("0. Quit")
    choice = input(" >>  ")
    exec_menu(choice)
    return
 
    # Les caracteristique de l'image base Histogramme couleur Qnt
def option1():
    exec(open("HistogrammeQnt.py").read())
   
# les caracterisque de l'image base Moment de Hu 
def option2():
    exec(open("Humoment.py").read())
  
    
    # lance ment de la fonction distance avec Histogramme Qnt
def option3():
    exec(open("DistanceHistCouleur.py").read())
  
    
    # Lancement de la foction distance avec Moment de Hu
def option4():
    exec(open("DistanceMomentHu.py").read())


# Lancement de la fonction permettant de trouver la distance Globale 
# Menu 3 SYSTEME DE	RECHERCHE D’IMAGES SIMILAIRES 
def option5():
    exec(open("DistanceGlobale.py").read())
    
# Lancement de la fonction permettant de faire une Classification Avec K-Means 
def option6():
    exec(open("K_means.py").read())
    
#  :	Utilisation	de	descripteurs locaux	et	approche	Bag-of-Words 
def option7(): 
    exec(open("bag_of_words.py").read())

#  PLUSIEURS	HISTOGRAMMES	COULEURS	PAR	IMAGE & L’INDEXATION	DU	VECTEUR	DE	BAG	OF	WORDS
def option8(): 
    exec(open("bonus.py").read())    

 
# Menu 2 SYSTEME DE	RECHERCHE D’IMAGES SIMILAIRES base sur les Distances 
def menu2():
    print ("SYSTEME DE	RECHERCHE D’IMAGES SIMILAIRES \n")
    print ("SVP Choisissez un menu pour demarrer: \n")
    
    print ("9. Distance basant sur Les histogrammes couleurs quantifiés	")
    print ("10. Disatance basant sur  Les moments de	 Hu")
    
    print ("11. Back")
    print ("0. Quit") 
    choice = input(" >>  ")
    exec_menu(choice)
    return
 
   

# Back to main menu
def back():
    menu_actions['main_menu']()
 
# Exit program
def exit():
    sys.exit()
 
# =======================
#    MENUS DEFINITIONS
# =======================
 
# Menu definition
menu_actions = {
    'main_menu': main_menu,
    '1': menu1,
    '2': menu2,
    '3': option5,
    '4': option6,
    '5': option7,
    '6': option8,
    '7': option1,
    '8': option2,
    '9': option3,
    '10': option4,
    #'9': option5,
    '11': back,
    '0': exit,
}
 
# =======================
#      MAIN PROGRAM
# =======================
 
# Main Program
if __name__ == "__main__":
    # Launch main menu
    main_menu()