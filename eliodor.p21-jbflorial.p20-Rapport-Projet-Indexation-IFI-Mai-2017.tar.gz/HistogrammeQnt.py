#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
#title           :HistogrammeQnt.py DESCRIPTION GLOBALE DU CONTENU DES IMAGES
#description     : Les caracteristique de l'image base Histogramme couleur Qnt
#author          : Florial Jean Baptiste , Eliodor Ednalson Guy Merlin 
#date            : 3/05/2017
#version         :0.1
#usage           :python HistogrammeQnt.py 
#notes           : Nous avons ultile la foction D'open CV 
#python_version  :3.6.0 
#=======================================================================

from matplotlib import pyplot as plt
import numpy as np
import argparse
import cv2

# "Nom de l'image Entrer au clavier")
print ("Entrer le	 nom du fichier image :")
monfichier= input(" >>  ")

#"Valeur pour la reduction de l'histogramme")
print ("Entrer la valeur permettant la reduction de l'Histogramme")
valeur_hist = input(" >>  ")
image = cv2.imread(monfichier)

#cv2.imshow("image", image)

# grab the image channels, initialize the tuple of colors,
# the figure and the flattened feature vector

chans = cv2.split(image)
colors = ("b", "g", "r")
plt.figure()
plt.title("histogrammes couleurs quantifiés")
plt.xlabel("Bins")
plt.ylabel("# of Pixels")
features = []

# loop over the image channels
for (chan, color) in zip(chans, colors):
	# create a histogram for the current channel and
	# concatenate the resulting histograms for each channel
    
	hist = cv2.calcHist([chan], [0], None, [int(valeur_hist)], [0, int(valeur_hist)])
	features.extend(hist)

	# plot the histogram
	plt.plot(hist, color = color)
	plt.xlim([0, int(valeur_hist)])

print ("2D histogrammes shape: %s, with %d values" % (
	hist.shape, hist.flatten().shape[0]))

# show the figures 
plt.show()
