#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed May 17 05:09:04 2017

"""

#!/usr/bin/env python
# -*- coding: utf-8 -*-
#title           :projetfinal.py Calcule de Hu Moment DESCRIPTION GLOBALE DU CONTENU DES IMAGES
#description     :Tes caracterisque de l'image base Moment de Hu 
#author          : Florial Jean Baptiste , Eliodor Ednalson Guy Merlin 
#date            : 3/05/2017
#version         :0.1
#usage           :python Humoment.py 
#notes           : Nous avons ultile la foction D'open CV 
#python_version  :3.6.0 
#=======================================================================

# Imports
import cv2
# "Nom de l'image Entrer au clavier")
print ("Entrer le	 nom du fichier image :")
monfichier= input(" >>  ")

image = cv2.imread(monfichier)
image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
#cv2.imshow("image", image)

# extract Hu Moments from the image -- this list of numbers
# is our 'feature vector' used to quantify the shape of the
# object in our image
features = cv2.HuMoments(cv2.moments(image)).flatten()
print ("")
print ("Le Moment de HU de l'image en Entrer: " )
print (features)
