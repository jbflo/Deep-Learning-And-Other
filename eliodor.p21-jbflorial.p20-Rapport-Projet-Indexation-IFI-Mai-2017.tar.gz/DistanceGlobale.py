#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
#title           :DistenceGlobale.py . FONCTION	GLOBALE	DE	SIMILARITE	ENTRE	DEUX	IMAGES
#description     :  Lancement de la fonction permettant de trouver la distance Globale
#author          : Florial Jean Baptiste , Eliodor Ednalson Guy Merlin 
#date            : 3/05/2017
#version         :0.1
#usage           :python DistenceGlobale.py 
#notes           : Nous avons ultile la foction D'open CV 
#python_version  :3.6.0 
#=======================================================================

# Imports
import cv2# Imports


# Utilisation 
# python compare.py -f nomfichier -M valeurPourLareductionDeHistogramme -N les_K_Images_les_plus_Similaires
# importation des packages necessaires 

from scipy.spatial import distance as dist
import matplotlib.pyplot as plt
import numpy as np
#import argparse
import glob


# "Nom de l'image Entrer au clavier")
print ("Entrer le	 nom	 du fichier image 1 ")
monfichier= input(" >>  ")

print ("Entrer le	 nom	 du fichier image 2 ")
monfichier2= input(" >>  ")

#"Valeur pour la reduction de l'histogramme")
print ("Entrer la valeur permettant la reduction de l'Histogramme")
valeur_hist = input(" >>  ") 


#"nombre d'images ayant les plus petites distances par rapport a notre image requete")
print ("Entrer le Nombre N d'image a comparer")
nb_image = input(" >>  ")

#"Le poids ")
print ("Entrer le Nombre poids prend une valeur entre	0 et 1")
poids = input(" >>  ")
#args = vars(ap.parse_args())

#print ("\n")
#print ("\nImage de requete = " + args["nomfichier"])
#print ("Valeur de M = " + args["valeurM"])
#print ("Valeur de N = " + args["valeurN"])
# Initialization

# dictionnaire d'index pour stocker le nom de l'image
# les histogrammes correspondants et le dictionnaire d'images
index = {}
index2 = {}
images = {}
imagesinput = [monfichier,monfichier2]


# Boucle dans le dossier des images pour les recuperer et traiter
for inputimages in imagesinput:
	# extract the image filename (assumed to be unique) and
	# load the image, updating the images dictionary
	filename = inputimages[inputimages.rfind("/") + 1:]
	image = cv2.imread(inputimages)
	images[filename] = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
	imageHu = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    

	# extract a 3D RGB color histogram from the image,
	# using 8 bins per channel, normalize, and update
	# the index
	humoment = cv2.HuMoments(cv2.moments(imageHu)).flatten()  
	#hist = cv2.normalize(hist,hist).flatten()
    
    	#cv2.imshow("image", image)
    
	# extract Hu Moments from the image -- this list of numbers
	# is our 'feature vector' used to quantify the shape of the
	# object in our image
    
	index2[filename] = humoment

	# extract a 3D RGB color histogram from the image,
	# using 8 bins per channel, normalize, and update
	# the index
	hist = cv2.calcHist([image], [0, 1, 2], None, [int(valeur_hist), int(valeur_hist), int(valeur_hist)],
		[0, 256, 0, 256, 0, 256])
	hist = cv2.normalize(hist,hist).flatten()
    
	index[filename] = hist


# initialize the scipy methods to compaute distances
SCIPY_METHODS = (
	("Euclidienne", dist.euclidean),
	("Manhattan", dist.cityblock),
	#("Chebysev", dist.chebyshev)
    )

# loop over the comparison methods
for (methodName, method) in SCIPY_METHODS:
	# initialize the dictionary dictionary
	results = {} 
	results2 = {} 
	if methodName=="Manhattan" :
		print ("\n\tAvec la distance " + methodName + "\n")
		print ("Image"+ "\t\t\t" +"Distance\n")

	if methodName=="Euclidienne" :
		print ("\n\tAvec la distance " + methodName + "\n")
		print ("Image"+ "\t\t\t" +"Distance\n")
           
           
	# loop over the index
	for (k, hist) in index.items():
		# compute the distance between the two histograms
		# using the method and update the results dictionary
		d = method(index[monfichier], hist)
		results[k] = d
         
	# sort the results 
	results = sorted([(v, k) for (k, v) in results.items()])
	
	# loop over the index2
	for (j, humoment) in index2.items():
		# compute the distance between the two histograms
		# using the method and update the results dictionary
		d1 = method(index2[monfichier], humoment)
		results2[j] = d1
         
	# sort the results 
	results2 = sorted([(u, j) for (j, u) in results2.items()])
	
	k=0
	for i in results :
		if k == int(nb_image )+1 :
			break      	
		if i[0] != 0.0 :
			if methodName=="Manhattan" :
				print ("")
				print ("Distance Calculer avec Les valeur de L'histogramme")
				print (str(i[1]) + "\t\t" + str(i[0]))		
			if methodName=="Euclidienne" :
				print ("")
				print ("Distance Calculer avec Les valeur de L'histogramme")
				print (str(i[1]) + "\t\t" + str(i[0]))
		k=k+1

	j=0			
	for b in results2 :
		if j == int(nb_image )+1 :
			break      
	
		if b[0] != 0.0 :
			if methodName=="Manhattan" :
				print ("")
				print ("Distance Calculer avec Les valeur du Moment de Hu")		
				print (str(b[1]) + "\t\t" + str(b[0]))
			if methodName=="Euclidienne" :	
				print ("")
				print ("Distance Calculer avec Les valeur du Moment de Hu")		
				print (str(b[1]) + "\t\t" + str(b[0]))

		j=j+1	
	print (" ")

	if methodName=="Manhattan" :
        
		print ("La Distance Globale Avec Manhattan")
		dg = float(poids) * float(i[0]) + (1-float(poids) ) * float(b[0])
		print (dg)

	if methodName=="Euclidienne" :
       
		print ("La Distance Globale Avec Euclidienne ")
		dg = float(poids) * float(i[0]) + (1-float(poids) ) * float(b[0])
		print (dg)
		       
                
			
	

	print ("")

	# show the query image
	fig = plt.figure("Query")
	ax = fig.add_subplot(1, 1, 1)
	#ax.imshow(images[monfichier])
	plt.axis("off")

	# initialize the results figure
	fig = plt.figure("Results: %s" % (methodName))
	fig.suptitle(methodName, fontsize = 20)

	# loop over the results
	for (i, (v, k)) in enumerate(results):
		# show the result
		ax = fig.add_subplot(1, len(images), i + 1)
		ax.set_title("%s: %.2f" % (k, v))
		plt.imshow(images[k])
		plt.axis("off")


# show the SciPy methods
#plt.show()



# initialize the results dictionary
results = {}

# Trier et ordonner les resultats
results = sorted([(v, k) for (k, v) in results.items()])

# Afficher l'image requete
fig = plt.figure("Query")
ax = fig.add_subplot(1, 1, 1)
#ax.imshow(images[monfichier])
plt.axis("off")

# initialize the results figure
#fig = plt.figure("Results: Custom Chi-Squared")
#fig.suptitle("Custom Chi-Squared", fontsize = 20)

# loop over the results
for (i, (v, k)) in enumerate(results):
	# show the result
	ax = fig.add_subplot(1, len(images), i + 1)
	ax.set_title("%s: %.2f" % (k, v))
	plt.imshow(images[k])
	plt.axis("off")

# show the custom method
#plt.show()
