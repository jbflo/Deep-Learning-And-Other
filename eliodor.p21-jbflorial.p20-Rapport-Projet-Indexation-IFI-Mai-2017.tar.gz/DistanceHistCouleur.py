#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
#title           :DistanceHistCouleur.py SYSTEME DE	RECHERCHE D’IMAGES SIMILAIRES
#description     :  la fonction distance avec Histogramme Qnt
#author          : Florial Jean Baptiste , Eliodor Ednalson Guy Merlin 
#date            : 3/05/2017
#version         :0.1
#usage           :python DistanceHistCouleur.py 
#notes           : Nous avons ultile la foction D'open CV 
#python_version  :3.6.0 
#=======================================================================
from scipy.spatial import distance as dist
import matplotlib.pyplot as plt
import numpy as np
#import argparse
import glob
import cv2

# "Nom de l'image Entrer au clavier")
print ("Entrer le	 nom	 du fichier image ")
monfichier= input(" >>  ")

#"Valeur pour la reduction de l'histogramme")
print ("Entrer la valeur permettant la reduction de l'Histogramme")
valeur_hist = input(" >>  ")


#"nombre d'images ayant les plus petites distances par rapport a notre image requete")
print ("Entrer le Nombre N d'image a comparer")
nb_image = input(" >>  ")
#args = vars(ap.parse_args())

# dictionnaire d'index pour stocker le nom de l'image
# les histogrammes correspondants et le dictionnaire d'images
index = {}
images = {}

# Boucle dans le dossier des images pour les recuperer et traiter
for imagePath in glob.glob("coil-100" + "/*.png"):
	# extract the image filename (assumed to be unique) and
	# load the image, updating the images dictionary
	filename = imagePath[imagePath.rfind("/") + 1:]
	image = cv2.imread(imagePath)
	images[filename] = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

	# extract a 3D RGB color histogram from the image,
	# using 8 bins per channel, normalize, and update
	# the index
	hist = cv2.calcHist([image], [0, 1, 2], None, [int(valeur_hist), int(valeur_hist), int(valeur_hist)],
		[0, 256, 0, 256, 0, 256])
	hist = cv2.normalize(hist,hist).flatten()
	index[filename] = hist


# initialize the scipy methods to compaute distances
SCIPY_METHODS = (
	("Euclidienne", dist.euclidean),
	("Manhattan", dist.cityblock),
	#("Chebysev", dist.chebyshev)
    )

# loop over the comparison methods
for (methodName, method) in SCIPY_METHODS:
	# initialize the dictionary dictionary
	results = {} 
	if methodName=="Manhattan" :
		print ("\n\tAvec la distance " + methodName + "\n")
		print ("Image"+ "\t\t\t" +"Distance\n")

	if methodName=="Euclidienne" :
		print ("\n\tAvec la distance " + methodName + "\n")
		print ("Image"+ "\t\t\t" +"Distance\n")
           
           
	# loop over the index
	for (k, hist) in index.items():
		# compute the distance between the two histograms
		# using the method and update the results dictionary
		d = method(index[monfichier], hist)
		results[k] = d
         
	# sort the results 
	results = sorted([(v, k) for (k, v) in results.items()])
	
	k=0
	for i in results :
		if k == int(nb_image )+1 :
			break      
		
		if i[0] != 0.0 :
			if methodName=="Manhattan" :
				print (str(i[1]) + "\t\t" + str(i[0]))
			if methodName=="Euclidienne" :
				print (str(i[1]) + "\t\t" + str(i[0]))
                
               	
		k=k+1

	print ("")

	# show the query image
	fig = plt.figure("Query")
	ax = fig.add_subplot(1, 1, 1)
	ax.imshow(images[monfichier])
	plt.axis("off")

	# initialize the results figure
	fig = plt.figure("Results: %s" % (methodName))
	fig.suptitle(methodName, fontsize = 20)

	# loop over the results
	for (i, (v, k)) in enumerate(results):
		# show the result
		ax = fig.add_subplot(1, len(images), i + 1)
		ax.set_title("%s: %.2f" % (k, v))
		plt.imshow(images[k])
		plt.axis("off")


# show the SciPy methods
#plt.show()



# initialize the results dictionary
results = {}

# Trier et ordonner les resultats
results = sorted([(v, k) for (k, v) in results.items()])

# Afficher l'image requete
fig = plt.figure("Query")
ax = fig.add_subplot(1, 1, 1)
ax.imshow(images[monfichier])
plt.axis("off")

# initialize the results figure
#fig = plt.figure("Results: Custom Chi-Squared")
#fig.suptitle("Custom Chi-Squared", fontsize = 20)

# loop over the results
for (i, (v, k)) in enumerate(results):
	# show the result
	ax = fig.add_subplot(1, len(images), i + 1)
	ax.set_title("%s: %.2f" % (k, v))
	plt.imshow(images[k])
	plt.axis("off")

# show the custom method
#plt.show()
